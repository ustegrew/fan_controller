# Eval: Oscillator, 25kHz

KiCad project for an evaluation board providing a 25kHz mutable oscillator. Oscillator is based on an AGC stabilized Wien Bridge. Muting via a CD4066 analog switch.
